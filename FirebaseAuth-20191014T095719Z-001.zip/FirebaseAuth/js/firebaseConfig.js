var firebaseConfig = {
  apiKey: "AIzaSyBILoAhk4mzi_vOT446bHKE2gKV9M6In1A",
  authDomain: "practice-ffc5b.firebaseapp.com",
  databaseURL: "https://practice-ffc5b.firebaseio.com",
  projectId: "practice-ffc5b",
  storageBucket: "",
  messagingSenderId: "375671488694",
  appId: "1:375671488694:web:ddca0131a0f9dd4f"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);