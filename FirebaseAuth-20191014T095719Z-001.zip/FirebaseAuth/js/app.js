$(document).ready(() => {
    var g_user = firebase.auth().currentUser
    console.log(g_user)

    firebase.auth().onAuthStateChanged(function (user) {
        if (user) {
            // User is signed in.
            $('#signIn').hide();
            $('#logged_id').show();
            $('#logged_id').append('<button class="btn text-white my-2 my-sm-0" disabled>' + user.email + '</button>')
            $('#makeBooking').show();
            $('#updateBooking').show();
            $('#deleteBooking').show();
            $('#viewBooking').show();
            $('#updatee').show();
            $('#num').show();
            $('#min').show();
            // $('#deviName').append('<label for="deviceName">' + booking.deviName + '</label>')
            //$('#device').hide();
            $('#logout').show();
            $('#summary').hide();
            $('#accountDelete').show();
            // $('#typee').show();
            // $('#typee').append('<label for="typee">' + costs + ' </label>')

            // ...
        } else {
            // User is signed out.
            $('#num').hide();
            $('#min').hide();
            $('#accountDelete').hide();
            $('#updatee').hide();
            $('#signIn').show();
            $('#logged_id').hide();
            $('#makeBooking').hide();
            $('#updateBooking').hide();
            $('#deleteBooking').hide();
            $('#viewBooking').hide();
            $('#paragraphy').hide();
            $('#logout').hide();
            $('#summary').show();
            $('#book').hide();
        }
    });
    $('#registerbtn').click(() => {

        $street = $('#street').val();
        $suburb = $('#suburb').val();
        $city = $('#city').val();
        $province = $('#province').val();
        $zip = $('#zip').val();
        $email = $('#email').val();
        $password = $('#password').val();
        $password_confirm = $('#password_confirm').val();
        $name = $('#name').val()
        $surname = $('#surname').val()
        $contactNumber = $('#contactNumber').val()
        $identityNum = $('#identityNumber').val()


        var erro;

        if ($identityNum === null || $email === null || $password === null || $street === null || $suburb === null || $city === null || $province === null || $province === "Choose..." || $zip === null) {
            erro = "Don't leave blank spaces or choose from the dropdown";
            alert(erro);

        } else if ($contactNumber.length != 10) {
            erro = "contact Number must be 10 digits";
            alert(erro);
        }
        else if ($identityNum.length != 13) {
            erro = "invalid ID Number";
            alert(error);
        } else if ($password != $password_confirm) {
            erro = "Password doesn't match";
            alert(erro);
        }
        else {
            firebase.auth().createUserWithEmailAndPassword($email, $password)
                .then((user) => {

                    setTimeout(
                        function () {
                            var userID = user.user.uid;
                            console.log(userID)
                            firebase.database().ref('user/' + userID).set({
                                email: $email,
                                name: $name,
                                surname: $surname,
                                contactNo: $contactNumber,
                                identityNo: $identityNum,
                                street: $street,
                                suburb: $suburb,
                                city: $city,
                                province: $province,
                                zip: $zip
                            }).then(() => {
                                location.pathname = './index.html'
                            })
                        }, 2000);
                })
                .catch((error) => {
                    console.log(error.message)
                    alert(error)
                })
        }
    })
    $('#logout').click(() => {
        firebase.auth().signOut()
    })
    $('#updateCancel').click(() => {
        location.pathname = '/index.html'
    })

    $('#UpdateAccount').click(() => {

        $name = $('#name1').val();
        $surname = $('#surname1').val();
        $street = $('#street').val();
        $suburb = $('#suburb').val();
        $city = $('#city').val();
        $province = $('#province').val();
        $zip = $('#zip').val();
        $model = $('#model').val();
        $deviName = $('#deviName').val();
        $comment = $('#comment').val();

        var userID = firebase.auth().currentUser.uid;
        var newPostKey = firebase.database().ref().child('booking').push().key;
        console.log(newPostKey)
        firebase.database().ref('booking/' + userID + '/' + newPostKey).set({
            // name: $name,
            // surname: $surname,
            name: namee,
            street: $street,
            suburb: $suburb,
            city: $city,
            province: $province,
            zip: $zip,
            model: $model,
            deviceName: $deviName,
            comment: $comment
        }).then(() => {
            location.pathname = '/payment.html'
        })
    })

    $('.login').click(() => {
        email = $('.username');
        password = $('.psw');

        firebase.auth().signInWithEmailAndPassword(email.val(), password.val())
            .then(() => {

                if (email == 'admin@electronic-repair.co.za') {
                    location.pathname = '/admin.html'
                } else {
                    console.log("logged in")
                    location.pathname = '/index.html'
                }
            })
            .catch((error) => {
                console.log(error.message);
                alert(error.message);
            })
    })
    $('#signIn').click(() => {
        location.pathname = './signin.html'
    })

    $('#makeBooking').click(() => {
        location.pathname = '/makebooking.html'
    })
    $('#bookCancel').click(() => {
        location.pathname = '/booking.html'
    })
    $('#back').click(() => {
        location.pathname = '/signin.html'
    })
    $('#updateBooking').click(() => {
        location.pathname = '/update.html'
    })
    $('#bookNext').click(() => {
        $model = $('#model').val();
        $deviName = $('#deviName').val();
        $comment = $('#comment').val();
        $collect = $('#collect').val();

        if ($model === null || $model === "Choose..." || $deviName === null || $comment === null || $collect === "Choose...") {
            alert("Don't leave blanks or choose from the dropdowns");
        } else {

            var userID = firebase.auth().currentUser.uid;
            var newPostKey = firebase.database().ref().child('booking').push().key;
            console.log(newPostKey)
            firebase.database().ref('booking/' + userID + '/' + newPostKey).set({
                model: $model,
                deviceName: $deviName,
                comment: $comment,
                collect: $collect
            }).then(() => {
                location.pathname = '/payment.html'
            })
        }
    })
})

$('#paybtn').click(() => {
    $holder = $('#holder').val();
    $bank = $('#bank').val();
    $cardno = $('#card').val();
    $cvv = $('#cvv').val();
    $expiry = $('#expiry').val();

    if ($holder == null || $bank == null || $bank == "Choose..." || $cardno == null || $cvv == null || $expiry == null) {
        alert("Please don't leave blank space(s) or you have to select from the dropdown")
    } else if ($cardno.length != 16) {
        alert("Invalid card number")
    } else if ($cvv.length != 3) {
        alert("invalid CVV number")
    } else if ($expiry < Date.now()) {
        alert('invalid date or maybe your card is expired')
    } else {

        var userID = firebase.auth().currentUser.uid;
        var newPostKey = firebase.database().ref().child('payement').push().key;
        console.log(newPostKey)
        firebase.database().ref('payement/' + userID + '/' + newPostKey).set({
            card_holder: $holder,
            bank: $bank,
            card_no: $cardno,
            cvv: $cvv,
            expiry_date: $expiry
        }).then(() => {
            alert("Thanks!... we are done for now...bye");
            location.pathname = './index.html'
        })
    }

});
